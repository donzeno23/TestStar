from __future__ import absolute_import

VERSION = (0, 1, 0)
__version__ = '.'.join(map(str, VERSION))

from .app import TestStar  # noqa